const struct arc_operand arc_operands[] = {
#define IGNORED
{ 0, 0, 0, ARC_OPERAND_IGNORE | ARC_OPERAND_UNSIGNED | ARC_OPERAND_NCHK, 0, 0 },
#define RA
{ 6, 0, 0, ARC_OPERAND_IR, 0, 0 },
#define RA_CHK
{ 6, 0, 0, ARC_OPERAND_IR, insert_ra_chk, 0 },
#define RB
{ 6, 12, 0, ARC_OPERAND_IR, insert_rb, extract_rb },
#define RB_CHK
{ 6, 12, 0, ARC_OPERAND_IR, insert_rb_chk, extract_rb },
#define RBB_S
{ 6, 12, 0, ARC_OPERAND_IR, insert_rbb, extract_rbb },
#define RBB_S_CHK
{ 6, 12, 0, ARC_OPERAND_IR, insert_rbb_chk, extract_rbb },
#define RC
{ 6, 6, 0, ARC_OPERAND_IR, 0, 0 },
#define RC_CHK
{ 6, 6, 0, ARC_OPERAND_IR, 0, 0 },
#define RBdup
{ 6, 12, 0, ARC_OPERAND_IR | ARC_OPERAND_DUPLICATE, insert_rb, extract_rb },
#define RAD
{ 6, 0, 0, ARC_OPERAND_IR | ARC_OPERAND_TRUNCATE, insert_rad, 0 },
#define RAD_CHK
{ 6, 0, 0, ARC_OPERAND_IR | ARC_OPERAND_TRUNCATE, insert_rad, 0 },
#define RCD
{ 6, 6, 0, ARC_OPERAND_IR | ARC_OPERAND_TRUNCATE, insert_rcd, 0 },
#define RBD
{ 6, 6, 0, ARC_OPERAND_IR | ARC_OPERAND_TRUNCATE, insert_rbd, extract_rb },
#define RBDdup
{ 6, 12, 0, ARC_OPERAND_IR | ARC_OPERAND_DUPLICATE | ARC_OPERAND_TRUNCATE, insert_rbd, extract_rb },
#define RA16
{ 4, 0, 0, ARC_OPERAND_IR, insert_ras, extract_ras },
#define RA_S
{ 4, 0, 0, ARC_OPERAND_IR, insert_ras, extract_ras },
#define RB16
{ 4, 8, 0, ARC_OPERAND_IR, insert_rbs, extract_rbs },
#define RB_S
{ 4, 8, 0, ARC_OPERAND_IR, insert_rbs, extract_rbs },
#define RB16dup
{ 4, 8, 0, ARC_OPERAND_IR | ARC_OPERAND_DUPLICATE, insert_rbs, extract_rbs },
#define RB_Sdup
{ 4, 8, 0, ARC_OPERAND_IR | ARC_OPERAND_DUPLICATE, insert_rbs, extract_rbs },
#define RC16
{ 4, 5, 0, ARC_OPERAND_IR, insert_rcs, extract_rcs },
#define RC_S
{ 4, 5, 0, ARC_OPERAND_IR, insert_rcs, extract_rcs },
#define R6H
{ 6, 5, 0, ARC_OPERAND_IR, insert_rhv1, extract_rhv1 },
#define R5H
{ 5, 5, 0, ARC_OPERAND_IR, insert_rhv2, extract_rhv2 },
#define RH_S
{ 5, 5, 0, ARC_OPERAND_IR, insert_rhv2, extract_rhv2 },
#define R5Hdup
{ 5, 5, 0, ARC_OPERAND_IR | ARC_OPERAND_DUPLICATE, insert_rhv2, extract_rhv2 },
#define RH_Sdup
{ 5, 5, 0, ARC_OPERAND_IR | ARC_OPERAND_DUPLICATE, insert_rhv2, extract_rhv2 },
#define RG
{ 5, 5, 0, ARC_OPERAND_IR, insert_g_s, extract_g_s },
#define G_S
{ 5, 5, 0, ARC_OPERAND_IR, insert_g_s, extract_g_s },
#define R0
{ 0, 0, 0, ARC_OPERAND_IR, insert_r0, extract_r0 },
#define R0_S
{ 0, 0, 0, ARC_OPERAND_IR, insert_r0, extract_r0 },
#define R1
{ 1, 0, 0, ARC_OPERAND_IR, insert_r1, extract_r1 },
#define R1_S
{ 1, 0, 0, ARC_OPERAND_IR, insert_r1, extract_r1 },
#define R2
{ 2, 0, 0, ARC_OPERAND_IR, insert_r2, extract_r2 },
#define R2_S
{ 2, 0, 0, ARC_OPERAND_IR, insert_r2, extract_r2 },
#define R3
{ 2, 0, 0, ARC_OPERAND_IR, insert_r3, extract_r3 },
#define R3_S
{ 2, 0, 0, ARC_OPERAND_IR, insert_r3, extract_r3 },
#define RSP
{ 5, 0, 0, ARC_OPERAND_IR, insert_sp, extract_sp },
#define SP_S
{ 5, 0, 0, ARC_OPERAND_IR, insert_sp, extract_sp },
#define SPdup
{ 5, 0, 0, ARC_OPERAND_IR | ARC_OPERAND_DUPLICATE, insert_sp, extract_sp },
#define SP_Sdup
{ 5, 0, 0, ARC_OPERAND_IR | ARC_OPERAND_DUPLICATE, insert_sp, extract_sp },
#define GP
{ 5, 0, 0, ARC_OPERAND_IR, insert_gp, extract_gp },
#define GP_S
{ 5, 0, 0, ARC_OPERAND_IR, insert_gp, extract_gp },
#define PCL_S
{ 1, 0, 0, ARC_OPERAND_IR | ARC_OPERAND_NCHK, insert_pcl, extract_pcl },
#define BLINK
{ 5, 0, 0, ARC_OPERAND_IR, insert_blink, extract_blink },
#define BLINK_S
{ 5, 0, 0, ARC_OPERAND_IR, insert_blink, extract_blink },
#define ILINK1
{ 5, 0, 0, ARC_OPERAND_IR, insert_ilink1, extract_ilink1 },
#define ILINK2
{ 5, 0, 0, ARC_OPERAND_IR, insert_ilink2, extract_ilink2 },
#define LIMM
{ 32, 0, BFD_RELOC_ARC_32_ME, ARC_OPERAND_LIMM, insert_limm, 0 },
#define LIMM_S
{ 32, 0, BFD_RELOC_ARC_32_ME, ARC_OPERAND_LIMM, insert_limm, 0 },
#define LO32
{ 32, 0, BFD_RELOC_ARC_LO32_ME, ARC_OPERAND_LIMM, insert_limm, 0 },
#define HI32
{ 32, 0, BFD_RELOC_ARC_HI32_ME, ARC_OPERAND_LIMM, insert_limm, 0 },
#define LIMM34
{ 34, 0, BFD_RELOC_ARC_PCLO32_ME_2, ARC_OPERAND_LIMM | ARC_OPERAND_SIGNED | ARC_OPERAND_ALIGNED32 | ARC_OPERAND_TRUNCATE | ARC_OPERAND_PCREL, insert_limm, 0 },
#define XIMM_S
{ 32, 0, BFD_RELOC_ARC_LO32_ME, ARC_OPERAND_LIMM | ARC_OPERAND_SIGNED, insert_limm, 0 },
#define XIMM
{ 32, 0, BFD_RELOC_ARC_LO32_ME, ARC_OPERAND_LIMM | ARC_OPERAND_SIGNED, insert_limm, 0 },
#define LIMMdup
{ 32, 0, 0, ARC_OPERAND_LIMM | ARC_OPERAND_DUPLICATE, insert_limm, 0 },
#define XIMMdup
{ 32, 0, 0, ARC_OPERAND_LIMM | ARC_OPERAND_DUPLICATE | ARC_OPERAND_SIGNED, insert_limm, 0 },
#define ZA
{ 0, 0, 0, ARC_OPERAND_UNSIGNED, insert_za, 0 },
#define ZB
{ 0, 0, 0, ARC_OPERAND_UNSIGNED, insert_za, 0 },
#define ZA_S
{ 0, 0, 0, ARC_OPERAND_UNSIGNED, insert_za, 0 },
#define ZB_S
{ 0, 0, 0, ARC_OPERAND_UNSIGNED, insert_za, 0 },
#define ZC_S
{ 0, 0, 0, ARC_OPERAND_UNSIGNED, insert_za, 0 },
#define RRANGE_EL
{ 4, 0, 0, ARC_OPERAND_UNSIGNED | ARC_OPERAND_NCHK | ARC_OPERAND_TRUNCATE, insert_rrange, extract_rrange },
#define R13_EL
{ 1, 0, 0, ARC_OPERAND_IR | ARC_OPERAND_IGNORE | ARC_OPERAND_NCHK, insert_r13el, extract_rrange },
#define FP_EL
{ 1, 0, 0, ARC_OPERAND_IR | ARC_OPERAND_IGNORE | ARC_OPERAND_NCHK, insert_fpel, extract_fpel },
#define BLINK_EL
{ 1, 0, 0, ARC_OPERAND_IR | ARC_OPERAND_IGNORE | ARC_OPERAND_NCHK, insert_blinkel, extract_blinkel },
#define PCL_EL
{ 1, 0, 0, ARC_OPERAND_IR | ARC_OPERAND_IGNORE | ARC_OPERAND_NCHK, insert_pclel, extract_pclel },
#define BRAKET
{ 0, 0, 0, ARC_OPERAND_FAKE | ARC_OPERAND_BRAKET, 0, 0 },
#define BRAKETdup
{ 0, 0, 0, ARC_OPERAND_FAKE | ARC_OPERAND_BRAKET, 0, 0 },
#define FKT_T
{ 1, 3, 0, ARC_OPERAND_FAKE, insert_Ybit, 0 },
#define FKT_NT
{ 1, 3, 0, ARC_OPERAND_FAKE, insert_NYbit, 0 },
#define UIMM6_20
{ 6, 0, 0, ARC_OPERAND_UNSIGNED, insert_uimm6_20, extract_uimm6_20 },
#define UIMM6_20R
{ 6, 0, -UIMM6_20R, ARC_OPERAND_UNSIGNED | ARC_OPERAND_PCREL, insert_uimm6_20, extract_uimm6_20 },
#define SIMM12_20
{ 12, 0, 0, ARC_OPERAND_SIGNED, insert_simm12_20, extract_simm12_20 },
#define SIMM12_20R
{ 12, 0, -SIMM12_20R, ARC_OPERAND_SIGNED | ARC_OPERAND_PCREL, insert_simm12_20, extract_simm12_20 },
#define UIMM12_20
{ 12, 0, 0, ARC_OPERAND_UNSIGNED, insert_simm12_20, extract_uimm12_20 },
#define SIMM3_5_S
{ 3, 0, 0, ARC_OPERAND_SIGNED | ARC_OPERAND_NCHK, insert_simm3s, extract_simm3s },
#define UIMM7_A32_11_S
{ 7, 0, 0, ARC_OPERAND_UNSIGNED | ARC_OPERAND_ALIGNED32 | ARC_OPERAND_TRUNCATE | ARC_OPERAND_IGNORE, insert_uimm7_a32_11_s, extract_uimm7_a32_11_s },
#define UIMM7_A32_11R_S
{ 7, 0, -UIMM7_A32_11R_S, ARC_OPERAND_UNSIGNED | ARC_OPERAND_ALIGNED32 | ARC_OPERAND_TRUNCATE | ARC_OPERAND_IGNORE | ARC_OPERAND_PCREL, insert_uimm7_a32_11_s, extract_uimm7_a32_11_s },
#define UIMM9_A32_11_S
{ 9, 0, 0, ARC_OPERAND_UNSIGNED | ARC_OPERAND_ALIGNED32 | ARC_OPERAND_TRUNCATE | ARC_OPERAND_IGNORE, insert_uimm9_a32_11_s, extract_uimm9_a32_11_s },
#define UIMM7_9_S
{ 7, 0, 0, ARC_OPERAND_UNSIGNED, insert_uimm7_9_s, extract_uimm7_9_s },
#define UIMM3_13_S
{ 3, 0, 0, ARC_OPERAND_UNSIGNED, insert_uimm3_13_s, extract_uimm3_13_s },
#define UIMM3_13R_S
{ 3, 0, -UIMM3_13R_S, ARC_OPERAND_UNSIGNED | ARC_OPERAND_PCREL, insert_uimm3_13_s, extract_uimm3_13_s },
#define SIMM11_A32_7_S
{ 11, 0, BFD_RELOC_ARC_SDA16_LD2, ARC_OPERAND_SIGNED | ARC_OPERAND_ALIGNED32 | ARC_OPERAND_TRUNCATE, insert_simm11_a32_7_s, extract_simm11_a32_7_s },
#define UIMM6_13_S
{ 6, 0, 0, ARC_OPERAND_UNSIGNED, insert_uimm6_13_s, extract_uimm6_13_s },
#define UIMM5_11_S
{ 5, 0, 0, ARC_OPERAND_UNSIGNED | ARC_OPERAND_IGNORE, insert_uimm5_11_s, extract_uimm5_11_s },
#define SIMM9_A16_8
{ 9, 0, BFD_RELOC_ARC_S9H_PCREL, ARC_OPERAND_SIGNED | ARC_OPERAND_ALIGNED16 | ARC_OPERAND_PCREL | ARC_OPERAND_TRUNCATE, insert_simm9_a16_8, extract_simm9_a16_8 },
#define UIMM6_8
{ 6, 0, 0, ARC_OPERAND_UNSIGNED, insert_uimm6_8, extract_uimm6_8 },
#define SIMM21_A16_5
{ 21, 0, BFD_RELOC_ARC_S21H_PCREL, ARC_OPERAND_SIGNED | ARC_OPERAND_ALIGNED16 | ARC_OPERAND_TRUNCATE | ARC_OPERAND_PCREL, insert_simm21_a16_5, extract_simm21_a16_5 },
#define SIMM25_A16_5
{ 25, 0, BFD_RELOC_ARC_S25H_PCREL, ARC_OPERAND_SIGNED | ARC_OPERAND_ALIGNED16 | ARC_OPERAND_TRUNCATE | ARC_OPERAND_PCREL, insert_simm25_a16_5, extract_simm25_a16_5 },
#define SIMM10_A16_7_S
{ 10, 0, BFD_RELOC_ARC_S10H_PCREL, ARC_OPERAND_SIGNED | ARC_OPERAND_ALIGNED16 | ARC_OPERAND_TRUNCATE | ARC_OPERAND_PCREL, insert_simm10_a16_7_s, extract_simm10_a16_7_s },
#define SIMM10_A16_7_Sbis
{ 10, 0, -SIMM10_A16_7_Sbis, ARC_OPERAND_SIGNED | ARC_OPERAND_ALIGNED16 | ARC_OPERAND_TRUNCATE, insert_simm10_a16_7_s, extract_simm10_a16_7_s },
#define SIMM7_A16_10_S
{ 7, 0, BFD_RELOC_ARC_S7H_PCREL, ARC_OPERAND_SIGNED | ARC_OPERAND_ALIGNED16 | ARC_OPERAND_TRUNCATE | ARC_OPERAND_PCREL, insert_simm7_a16_10_s, extract_simm7_a16_10_s },
#define SIMM21_A32_5
{ 21, 0, BFD_RELOC_ARC_S21W_PCREL, ARC_OPERAND_SIGNED | ARC_OPERAND_ALIGNED32 | ARC_OPERAND_TRUNCATE | ARC_OPERAND_PCREL, insert_simm21_a32_5, extract_simm21_a32_5 },
#define SIMM25_A32_5
{ 25, 0, BFD_RELOC_ARC_S25W_PCREL, ARC_OPERAND_SIGNED | ARC_OPERAND_ALIGNED32 | ARC_OPERAND_TRUNCATE | ARC_OPERAND_PCREL, insert_simm25_a32_5, extract_simm25_a32_5 },
#define SIMM13_A32_5_S
{ 13, 0, BFD_RELOC_ARC_S13_PCREL, ARC_OPERAND_SIGNED | ARC_OPERAND_ALIGNED32 | ARC_OPERAND_TRUNCATE | ARC_OPERAND_PCREL, insert_simm13_a32_5_s, extract_simm13_a32_5_s },
#define SIMM8_A16_9_S
{ 8, 0, BFD_RELOC_ARC_S8H_PCREL, ARC_OPERAND_SIGNED | ARC_OPERAND_ALIGNED16 | ARC_OPERAND_TRUNCATE | ARC_OPERAND_PCREL, insert_simm8_a16_9_s, extract_simm8_a16_9_s },
#define UIMM10_6_S_JLIOFF
{ 12, 0, BFD_RELOC_ARC_JLI_SECTOFF, ARC_OPERAND_UNSIGNED | ARC_OPERAND_ALIGNED32 | ARC_OPERAND_TRUNCATE, insert_uimm10_6_s, extract_uimm10_6_s },
#define UIMM3_23
{ 3, 0, 0, ARC_OPERAND_UNSIGNED, insert_uimm3_23, extract_uimm3_23 },
#define UIMM10_6_S
{ 10, 0, 0, ARC_OPERAND_UNSIGNED, insert_uimm10_6_s, extract_uimm10_6_s },
#define UIMM10_13_S
{ 10, 0, 0, ARC_OPERAND_UNSIGNED, insert_uimm10_13_s, extract_uimm10_13_s },
#define UIMM6_11_S
{ 6, 0, 0, ARC_OPERAND_UNSIGNED, insert_uimm6_11_s, extract_uimm6_11_s },
#define SIMM9_8
{ 9, 0, BFD_RELOC_ARC_SDA_LDST, ARC_OPERAND_SIGNED | ARC_OPERAND_IGNORE, insert_simm9_8, extract_simm9_8 },
#define SIMM9_8R
{ 9, 0, -SIMM9_8R, ARC_OPERAND_SIGNED | ARC_OPERAND_IGNORE | ARC_OPERAND_PCREL, insert_simm9_8, extract_simm9_8 },
#define UIMM10_A32_8_S
{ 10, 0, -UIMM10_A32_8_S, ARC_OPERAND_UNSIGNED | ARC_OPERAND_ALIGNED32 | ARC_OPERAND_TRUNCATE | ARC_OPERAND_PCREL, insert_uimm10_a32_8_s, extract_uimm10_a32_8_s },
#define SIMM9_7_S
{ 9, 0, BFD_RELOC_ARC_SDA16_LD, ARC_OPERAND_SIGNED, insert_simm9_7_s, extract_simm9_7_s },
#define UIMM6_A16_11_S
{ 6, 0, 0, ARC_OPERAND_UNSIGNED | ARC_OPERAND_ALIGNED16 | ARC_OPERAND_TRUNCATE | ARC_OPERAND_IGNORE, insert_uimm6_a16_11_s, extract_uimm6_a16_11_s },
#define UIMM5_A32_11_S
{ 5, 0, 0, ARC_OPERAND_UNSIGNED | ARC_OPERAND_ALIGNED32 | ARC_OPERAND_TRUNCATE | ARC_OPERAND_IGNORE, insert_uimm5_a32_11_s, extract_uimm5_a32_11_s },
#define SIMM11_A32_13_S
{ 11, 0, BFD_RELOC_ARC_SDA16_ST2, ARC_OPERAND_SIGNED | ARC_OPERAND_ALIGNED32 | ARC_OPERAND_TRUNCATE, insert_simm11_a32_13_s, extract_simm11_a32_13_s },
#define UIMM7_13_S
{ 7, 0, 0, ARC_OPERAND_UNSIGNED, insert_uimm7_13_s, extract_uimm7_13_s },
#define UIMM6_A16_21
{ 6, 0, 0, ARC_OPERAND_UNSIGNED | ARC_OPERAND_ALIGNED16 | ARC_OPERAND_TRUNCATE, insert_uimm6_a16_21, extract_uimm6_a16_21 },
#define UIMM7_11_S
{ 7, 0, 0, ARC_OPERAND_UNSIGNED, insert_uimm7_11_s, extract_uimm7_11_s },
#define UIMM7_A16_20
{ 7, 0, -UIMM7_A16_20, ARC_OPERAND_UNSIGNED | ARC_OPERAND_ALIGNED16 | ARC_OPERAND_TRUNCATE | ARC_OPERAND_PCREL, insert_uimm7_a16_20, extract_uimm7_a16_20 },
#define SIMM13_A16_20
{ 13, 0, BFD_RELOC_ARC_S13H_PCREL, ARC_OPERAND_SIGNED | ARC_OPERAND_ALIGNED16 | ARC_OPERAND_TRUNCATE | ARC_OPERAND_PCREL, insert_simm13_a16_20, extract_simm13_a16_20 },
#define UIMM8_8_S
{ 8, 0, 0, ARC_OPERAND_UNSIGNED, insert_uimm8_8_s, extract_uimm8_8_s },
#define UIMM8_8R_S
{ 8, 0, -UIMM8_8R_S, ARC_OPERAND_UNSIGNED | ARC_OPERAND_PCREL, insert_uimm8_8_s, extract_uimm8_8_s },
#define W6
{ 6, 0, 0, ARC_OPERAND_SIGNED, insert_w6, extract_w6 },
#define UIMM6_5_S
{ 6, 0, 0, ARC_OPERAND_UNSIGNED, insert_uimm6_5_s, extract_uimm6_5_s },
#define NPS_R_DST_3B
{ 3, 24, 0, ARC_OPERAND_IR | ARC_OPERAND_NCHK, insert_nps_3bit_reg_at_24_dst, extract_nps_3bit_reg_at_24_dst },
#define NPS_R_SRC1_3B
{ 3, 24, 0, ARC_OPERAND_IR | ARC_OPERAND_DUPLICATE | ARC_OPERAND_NCHK, insert_nps_3bit_reg_at_24_dst, extract_nps_3bit_reg_at_24_dst },
#define NPS_R_SRC2_3B
{ 3, 21, 0, ARC_OPERAND_IR | ARC_OPERAND_NCHK, insert_nps_3bit_reg_at_21_src2, extract_nps_3bit_reg_at_21_src2 },
#define NPS_R_DST
{ 6, 21, 0, ARC_OPERAND_IR, NULL, NULL },
#define NPS_R_SRC1
{ 6, 21, 0, ARC_OPERAND_IR | ARC_OPERAND_DUPLICATE, NULL, NULL },
#define NPS_BITOP_DST_POS
{ 5, 5, 0, ARC_OPERAND_UNSIGNED, 0, 0 },
#define NPS_BITOP_SRC_POS
{ 5, 0, 0, ARC_OPERAND_UNSIGNED, 0, 0 },
#define NPS_BITOP_SIZE
{ 5, 10, 0, ARC_OPERAND_UNSIGNED | ARC_OPERAND_NCHK, insert_nps_bitop_size, extract_nps_bitop_size },
#define NPS_BITOP_DST_POS_SZ
{ 5, 0, 0, ARC_OPERAND_UNSIGNED, insert_nps_dst_pos_and_size, extract_nps_dst_pos_and_size },
#define NPS_BITOP_SIZE_2B
{ 0, 0, 0, ARC_OPERAND_UNSIGNED | ARC_OPERAND_NCHK, insert_nps_bitop_size_2b, extract_nps_bitop_size_2b },
#define NPS_BITOP_UIMM8
{ 8, 0, 0, ARC_OPERAND_UNSIGNED, insert_nps_bitop_uimm8, extract_nps_bitop_uimm8 },
#define NPS_UIMM16
{ 16, 0, 0, ARC_OPERAND_UNSIGNED, NULL, NULL },
#define NPS_SIMM16
{ 16, 0, 0, ARC_OPERAND_SIGNED, NULL, NULL },
#define NPS_RFLT_UIMM6
{ 6, 6, 0, ARC_OPERAND_UNSIGNED | ARC_OPERAND_NCHK, insert_nps_rflt_uimm6, extract_nps_rflt_uimm6 },
#define NPS_XLDST_UIMM16
{ 16, 0, BFD_RELOC_ARC_NPS_CMEM16, ARC_OPERAND_UNSIGNED | ARC_OPERAND_NCHK, insert_nps_cmem_uimm16, extract_nps_cmem_uimm16 },
#define NPS_SRC2_POS
{ 0, 0, 0, ARC_OPERAND_UNSIGNED | ARC_OPERAND_NCHK, insert_nps_src2_pos, extract_nps_src2_pos },
#define NPS_SRC1_POS
{ 0, 0, 0, ARC_OPERAND_UNSIGNED | ARC_OPERAND_NCHK, insert_nps_src1_pos, extract_nps_src1_pos },
#define NPS_ADDB_SIZE
{ 0, 0, 0, ARC_OPERAND_UNSIGNED | ARC_OPERAND_NCHK, insert_nps_addb_size, extract_nps_addb_size },
#define NPS_ANDB_SIZE
{ 0, 0, 0, ARC_OPERAND_UNSIGNED | ARC_OPERAND_NCHK, insert_nps_andb_size, extract_nps_andb_size },
#define NPS_FXORB_SIZE
{ 0, 0, 0, ARC_OPERAND_UNSIGNED | ARC_OPERAND_NCHK, insert_nps_fxorb_size, extract_nps_fxorb_size },
#define NPS_WXORB_SIZE
{ 0, 0, 0, ARC_OPERAND_UNSIGNED | ARC_OPERAND_NCHK, insert_nps_wxorb_size, extract_nps_wxorb_size },
#define NPS_R_XLDST
{ 6, 5, 0, ARC_OPERAND_IR, NULL, NULL },
#define NPS_DIV_UIMM4
{ 4, 5, 0, ARC_OPERAND_UNSIGNED, NULL, NULL },
#define NPS_QCMP_SIZE
{ 0, 0, 0, ARC_OPERAND_UNSIGNED | ARC_OPERAND_NCHK, insert_nps_qcmp_size, extract_nps_qcmp_size },
#define NPS_QCMP_M1
{ 1, 14, 0, ARC_OPERAND_UNSIGNED, NULL, extract_nps_qcmp_m1 },
#define NPS_QCMP_M2
{ 1, 15, 0, ARC_OPERAND_UNSIGNED, NULL, extract_nps_qcmp_m2 },
#define NPS_QCMP_M3
{ 4, 5, 0, ARC_OPERAND_UNSIGNED, NULL, extract_nps_qcmp_m3 },
#define NPS_CALC_ENTRY_SIZE
{ 0, 0, 0, ARC_OPERAND_UNSIGNED | ARC_OPERAND_NCHK, insert_nps_calc_entry_size, extract_nps_calc_entry_size },
#define NPS_R_DST_3B_SHORT
{ 3, 8, 0, ARC_OPERAND_IR | ARC_OPERAND_NCHK, insert_nps_3bit_reg_at_8_dst, extract_nps_3bit_reg_at_8_dst },
#define NPS_R_SRC1_3B_SHORT
{ 3, 8, 0, ARC_OPERAND_IR | ARC_OPERAND_DUPLICATE | ARC_OPERAND_NCHK, insert_nps_3bit_reg_at_8_dst, extract_nps_3bit_reg_at_8_dst },
#define NPS_R_SRC2_3B_SHORT
{ 3, 5, 0, ARC_OPERAND_IR | ARC_OPERAND_NCHK, insert_nps_3bit_reg_at_5_src2, extract_nps_3bit_reg_at_5_src2 },
#define NPS_BITOP_SIZE2
{ 5, 25, 0, ARC_OPERAND_UNSIGNED | ARC_OPERAND_NCHK, insert_nps_bitop2_size, extract_nps_bitop2_size },
#define NPS_BITOP_SIZE1
{ 5, 20, 0, ARC_OPERAND_UNSIGNED | ARC_OPERAND_NCHK, insert_nps_bitop1_size, extract_nps_bitop1_size },
#define NPS_BITOP_DST_POS3_POS4
{ 5, 0, 0, ARC_OPERAND_UNSIGNED, insert_nps_bitop_dst_pos3_pos4, extract_nps_bitop_dst_pos3_pos4 },
#define NPS_BITOP_DST_POS4
{ 5, 42, 0, ARC_OPERAND_UNSIGNED, NULL, NULL },
#define NPS_BITOP_DST_POS3
{ 5, 37, 0, ARC_OPERAND_UNSIGNED, NULL, NULL },
#define NPS_BITOP_DST_POS2
{ 5, 15, 0, ARC_OPERAND_UNSIGNED, NULL, NULL },
#define NPS_BITOP_DST_POS1
{ 5, 10, 0, ARC_OPERAND_UNSIGNED, NULL, NULL },
#define NPS_BITOP_SRC_POS4
{ 5, 32, 0, ARC_OPERAND_UNSIGNED, NULL, NULL },
#define NPS_BITOP_SRC_POS3
{ 5, 20, 0, ARC_OPERAND_UNSIGNED, NULL, NULL },
#define NPS_BITOP_SRC_POS2
{ 5, 5, 0, ARC_OPERAND_UNSIGNED, NULL, NULL },
#define NPS_BITOP_SRC_POS1
{ 5, 0, 0, ARC_OPERAND_UNSIGNED, NULL, NULL },
#define NPS_BITOP_MOD4
{ 2, 0, 0, ARC_OPERAND_UNSIGNED, insert_nps_bitop_mod4, extract_nps_bitop_mod4 },
#define NPS_BITOP_MOD3
{ 2, 29, 0, ARC_OPERAND_UNSIGNED, NULL, NULL },
#define NPS_BITOP_MOD2
{ 2, 27, 0, ARC_OPERAND_UNSIGNED, NULL, NULL },
#define NPS_BITOP_MOD1
{ 2, 25, 0, ARC_OPERAND_UNSIGNED, NULL, NULL },
#define NPS_BITOP_INS_EXT
{ 5, 20, 0, ARC_OPERAND_UNSIGNED, insert_nps_bitop_ins_ext, extract_nps_bitop_ins_ext },
#define NPS_FIELD_START_POS
{ 3, 3, 0, ARC_OPERAND_UNSIGNED, NULL, NULL },
#define NPS_FIELD_SIZE
{ 3, 6, 0, ARC_OPERAND_UNSIGNED | ARC_OPERAND_NCHK, insert_nps_field_size, extract_nps_field_size },
#define NPS_SHIFT_FACTOR
{ 3, 9, 0, ARC_OPERAND_UNSIGNED | ARC_OPERAND_NCHK, insert_nps_shift_factor, extract_nps_shift_factor },
#define NPS_BITS_TO_SCRAMBLE
{ 3, 12, 0, ARC_OPERAND_UNSIGNED | ARC_OPERAND_NCHK, insert_nps_bits_to_scramble, extract_nps_bits_to_scramble },
#define NPS_SRC2_POS_5B
{ 5, 5, 0, ARC_OPERAND_UNSIGNED, NULL, NULL },
#define NPS_BDLEN_MAX_LEN
{ 8, 5, 0, ARC_OPERAND_UNSIGNED | ARC_OPERAND_NCHK, insert_nps_bdlen_max_len, extract_nps_bdlen_max_len },
#define NPS_MIN_HOFS
{ 4, 6, 0, ARC_OPERAND_UNSIGNED | ARC_OPERAND_NCHK, insert_nps_min_hofs, extract_nps_min_hofs },
#define NPS_PSBC
{ 1, 11, 0, ARC_OPERAND_UNSIGNED, NULL, NULL },
#define NPS_DPI_DST
{ 5, 11, 0, ARC_OPERAND_IR, NULL, NULL },
#define NPS_DPI_SRC1_3B
{ 3, 24, 0, ARC_OPERAND_IR | ARC_OPERAND_NCHK, insert_nps_3bit_reg_at_24_dst, extract_nps_3bit_reg_at_24_dst },
#define NPS_HASH_WIDTH
{ 5, 6, 0, ARC_OPERAND_UNSIGNED | ARC_OPERAND_NCHK, insert_nps_hash_width, extract_nps_hash_width },
#define NPS_HASH_PERM
{ 3, 2, 0, ARC_OPERAND_UNSIGNED, NULL, NULL },
#define NPS_HASH_NONLINEAR
{ 1, 5, 0, ARC_OPERAND_UNSIGNED, NULL, NULL },
#define NPS_HASH_BASEMAT
{ 2, 0, 0, ARC_OPERAND_UNSIGNED, NULL, NULL },
#define NPS_HASH_LEN
{ 3, 2, 0, ARC_OPERAND_UNSIGNED | ARC_OPERAND_NCHK, insert_nps_hash_len, extract_nps_hash_len },
#define NPS_HASH_OFS
{ 2, 0, 0, ARC_OPERAND_UNSIGNED, NULL, NULL },
#define NPS_HASH_BASEMAT2
{ 1, 5, 0, ARC_OPERAND_UNSIGNED, NULL, NULL },
#define NPS_E4BY_INDEX0
{ 3, 8, 0, ARC_OPERAND_UNSIGNED, NULL, NULL },
#define NPS_E4BY_INDEX1
{ 3, 5, 0, ARC_OPERAND_UNSIGNED, NULL, NULL },
#define NPS_E4BY_INDEX2
{ 3, 2, 0, ARC_OPERAND_UNSIGNED, NULL, NULL },
#define NPS_E4BY_INDEX3
{ 2, 0, 0, ARC_OPERAND_UNSIGNED | ARC_OPERAND_NCHK, insert_nps_index3, extract_nps_index3 },
#define COLON
{ 0, 0, 0, ARC_OPERAND_COLON | ARC_OPERAND_FAKE, NULL, NULL },
#define NPS_BD
{ 0, 0, 0, ARC_OPERAND_ADDRTYPE | ARC_OPERAND_NCHK, insert_nps_bd, extract_nps_bd },
#define NPS_JID
{ 0, 0, 0, ARC_OPERAND_ADDRTYPE | ARC_OPERAND_NCHK, insert_nps_jid, extract_nps_jid },
#define NPS_LBD
{ 0, 0, 0, ARC_OPERAND_ADDRTYPE | ARC_OPERAND_NCHK, insert_nps_lbd, extract_nps_lbd },
#define NPS_MBD
{ 0, 0, 0, ARC_OPERAND_ADDRTYPE | ARC_OPERAND_NCHK, insert_nps_mbd, extract_nps_mbd },
#define NPS_SD
{ 0, 0, 0, ARC_OPERAND_ADDRTYPE | ARC_OPERAND_NCHK, insert_nps_sd, extract_nps_sd },
#define NPS_SM
{ 0, 0, 0, ARC_OPERAND_ADDRTYPE | ARC_OPERAND_NCHK, insert_nps_sm, extract_nps_sm },
#define NPS_XA
{ 0, 0, 0, ARC_OPERAND_ADDRTYPE | ARC_OPERAND_NCHK, insert_nps_xa, extract_nps_xa },
#define NPS_XD
{ 0, 0, 0, ARC_OPERAND_ADDRTYPE | ARC_OPERAND_NCHK, insert_nps_xd, extract_nps_xd },
#define NPS_CD
{ 0, 0, 0, ARC_OPERAND_ADDRTYPE | ARC_OPERAND_NCHK, insert_nps_cd, extract_nps_cd },
#define NPS_CBD
{ 0, 0, 0, ARC_OPERAND_ADDRTYPE | ARC_OPERAND_NCHK, insert_nps_cbd, extract_nps_cbd },
#define NPS_CJID
{ 0, 0, 0, ARC_OPERAND_ADDRTYPE | ARC_OPERAND_NCHK, insert_nps_cjid, extract_nps_cjid },
#define NPS_CLBD
{ 0, 0, 0, ARC_OPERAND_ADDRTYPE | ARC_OPERAND_NCHK, insert_nps_clbd, extract_nps_clbd },
#define NPS_CM
{ 0, 0, 0, ARC_OPERAND_ADDRTYPE | ARC_OPERAND_NCHK, insert_nps_cm, extract_nps_cm },
#define NPS_CSD
{ 0, 0, 0, ARC_OPERAND_ADDRTYPE | ARC_OPERAND_NCHK, insert_nps_csd, extract_nps_csd },
#define NPS_CXA
{ 0, 0, 0, ARC_OPERAND_ADDRTYPE | ARC_OPERAND_NCHK, insert_nps_cxa, extract_nps_cxa },
#define NPS_CXD
{ 0, 0, 0, ARC_OPERAND_ADDRTYPE | ARC_OPERAND_NCHK, insert_nps_cxd, extract_nps_cxd },
#define NPS_BD_TYPE
{ 1, 10, 0, ARC_OPERAND_UNSIGNED, NULL, NULL },
#define NPS_BMU_NUM
{ 3, 0, 0, ARC_OPERAND_UNSIGNED | ARC_OPERAND_NCHK, insert_nps_bd_num_buff, extract_nps_bd_num_buff },
#define NPS_PMU_NXT_DST
{ 4, 6, 0, ARC_OPERAND_UNSIGNED, NULL, NULL },
#define NPS_WHASH_SIZE
{ 6, 6, 0, ARC_OPERAND_UNSIGNED | ARC_OPERAND_NCHK, insert_nps_size_16bit, extract_nps_size_16bit },
#define NPS_PMU_NUM_JOB
{ 2, 6, 0, ARC_OPERAND_UNSIGNED | ARC_OPERAND_NCHK, insert_nps_pmu_num_job, extract_nps_pmu_num_job },
#define NPS_DMA_IMM_ENTRY
{ 3, 2, 0, ARC_OPERAND_UNSIGNED | ARC_OPERAND_NCHK, insert_nps_imm_entry, extract_nps_imm_entry },
#define NPS_DMA_IMM_OFFSET
{ 4, 10, 0, ARC_OPERAND_UNSIGNED | ARC_OPERAND_NCHK, insert_nps_imm_offset, extract_nps_imm_offset },
#define NPS_MISC_IMM_SIZE
{ 7, 0, 0, ARC_OPERAND_UNSIGNED, NULL, NULL },
#define NPS_MISC_IMM_OFFSET
{ 5, 8, 0, ARC_OPERAND_UNSIGNED | ARC_OPERAND_NCHK, insert_nps_misc_imm_offset, extract_nps_misc_imm_offset },
#define NPS_R_DST_3B_48
{ 3, 40, 0, ARC_OPERAND_IR | ARC_OPERAND_NCHK, insert_nps_3bit_reg_at_40_dst, extract_nps_3bit_reg_at_40_dst },
#define NPS_R_SRC1_3B_48
{ 3, 40, 0, ARC_OPERAND_IR | ARC_OPERAND_DUPLICATE | ARC_OPERAND_NCHK, insert_nps_3bit_reg_at_40_dst, extract_nps_3bit_reg_at_40_dst },
#define NPS_R_SRC2_3B_48
{ 3, 37, 0, ARC_OPERAND_IR | ARC_OPERAND_NCHK, insert_nps_3bit_reg_at_37_src2, extract_nps_3bit_reg_at_37_src2 },
#define NPS_R_DST_3B_64
{ 3, 56, 0, ARC_OPERAND_IR | ARC_OPERAND_NCHK, insert_nps_3bit_reg_at_56_dst, extract_nps_3bit_reg_at_56_dst },
#define NPS_R_SRC1_3B_64
{ 3, 56, 0, ARC_OPERAND_IR | ARC_OPERAND_DUPLICATE | ARC_OPERAND_NCHK, insert_nps_3bit_reg_at_56_dst, extract_nps_3bit_reg_at_56_dst },
#define NPS_R_SRC2_3B_64
{ 3, 53, 0, ARC_OPERAND_IR | ARC_OPERAND_NCHK, insert_nps_3bit_reg_at_53_src2, extract_nps_3bit_reg_at_53_src2 },
#define NPS_RA_64
{ 6, 53, 0, ARC_OPERAND_IR, NULL, NULL },
#define NPS_RB_64
{ 5, 48, 0, ARC_OPERAND_IR, NULL, NULL },
#define NPS_RBdup_64
{ 5, 43, 0, ARC_OPERAND_IR | ARC_OPERAND_DUPLICATE, NULL, NULL },
#define NPS_RBdouble_64
{ 10, 43, 0, ARC_OPERAND_IR | ARC_OPERAND_NCHK, insert_nps_rbdouble_64, extract_nps_rbdouble_64 },
#define NPS_RC_64
{ 5, 43, 0, ARC_OPERAND_IR, NULL, NULL },
#define NPS_UIMM16_0_64
{ 16, 0, 0, ARC_OPERAND_UNSIGNED, NULL, NULL },
#define NPS_PROTO_SIZE
{ 6, 16, 0, ARC_OPERAND_UNSIGNED | ARC_OPERAND_NCHK, insert_nps_proto_size, extract_nps_proto_size },
#define FA
{ 5, 6, 0, ARC_OPERAND_IR | ARC_OPERAND_FP, 0, 0 },
#define FB
{ 5, 0, 0, ARC_OPERAND_IR | ARC_OPERAND_FP, 0, 0 },
#define FC
{ 5, 0, 0, ARC_OPERAND_IR | ARC_OPERAND_FP, insert_fs2, extract_fs2 },
#define FD
{ 5, 19, 0, ARC_OPERAND_IR | ARC_OPERAND_FP, 0, 0 },
#define FDA
{ 5, 6, 0, ARC_OPERAND_IR | ARC_OPERAND_FP | ARC_OPERAND_TRUNCATE, 0, 0 },
#define FDB
{ 5, 0, 0, ARC_OPERAND_IR | ARC_OPERAND_FP | ARC_OPERAND_TRUNCATE, 0, 0 },
#define FDC
{ 5, 0, 0, ARC_OPERAND_IR | ARC_OPERAND_FP | ARC_OPERAND_TRUNCATE, insert_fs2, extract_fs2 },
#define FDD
{ 5, 19, 0, ARC_OPERAND_IR | ARC_OPERAND_FP | ARC_OPERAND_TRUNCATE, 0, 0 },
#define FRD
{ 5, 6, 0, ARC_OPERAND_IR, 0, 0 },
#define FRB
{ 5, 0, 0, ARC_OPERAND_IR, insert_fs2, extract_fs2 },
#define UIMM5_FP
{ 5, 0, 0, ARC_OPERAND_UNSIGNED, insert_fs2, extract_fs2 },
};
const struct arc_flag_operand arc_flag_operands[] = {
#define F_ALWAYS
{ "al", 0, 0, 0, 0 },
#define F_RA
{ "ra", 0, 0, 0, 0 },
#define F_EQUAL
{ "eq", 1, 5, 0, 1 },
#define F_ZERO
{ "z", 1, 5, 0, 0 },
#define F_NOTEQUAL
{ "ne", 2, 5, 0, 1 },
#define F_NOTZERO
{ "nz", 2, 5, 0, 0 },
#define F_POZITIVE
{ "p", 3, 5, 0, 1 },
#define F_PL
{ "pl", 3, 5, 0, 0 },
#define F_NEGATIVE
{ "n", 4, 5, 0, 1 },
#define F_MINUS
{ "mi", 4, 5, 0, 0 },
#define F_CARRY
{ "c", 5, 5, 0, 1 },
#define F_CARRYSET
{ "cs", 5, 5, 0, 0 },
#define F_LOWER
{ "lo", 5, 5, 0, 0 },
#define F_CARRYCLR
{ "cc", 6, 5, 0, 0 },
#define F_NOTCARRY
{ "nc", 6, 5, 0, 1 },
#define F_HIGHER
{ "hs", 6, 5, 0, 0 },
#define F_OVERFLOWSET
{ "vs", 7, 5, 0, 0 },
#define F_OVERFLOW
{ "v", 7, 5, 0, 1 },
#define F_NOTOVERFLOW
{ "nv", 8, 5, 0, 1 },
#define F_OVERFLOWCLR
{ "vc", 8, 5, 0, 0 },
#define F_GT
{ "gt", 9, 5, 0, 1 },
#define F_GE
{ "ge", 10, 5, 0, 1 },
#define F_LT
{ "lt", 11, 5, 0, 1 },
#define F_LE
{ "le", 12, 5, 0, 1 },
#define F_HI
{ "hi", 13, 5, 0, 1 },
#define F_LS
{ "ls", 14, 5, 0, 1 },
#define F_PNZ
{ "pnz", 15, 5, 0, 1 },
#define F_NJ
{ "nj", 21, 5, 0, 1 },
#define F_NM
{ "nm", 23, 5, 0, 1 },
#define F_NO_T
{ "nt", 24, 5, 0, 1 },
#define F_FLAG
{ "f", 1, 1, 15, 1 },
#define F_FFAKE
{ "f", 0, 0, 0, 1 },
#define F_AQ
{ "aq", 1, 1, 15, 1 },
#define F_RL
{ "rl", 1, 1, 15, 1 },
#define F_ATO_ADD
{ "add", 0, 3, 0, 1 },
#define F_ATO_OR
{ "or", 1, 3, 0, 1 },
#define F_ATO_AND
{ "and", 2, 3, 0, 1 },
#define F_ATO_XOR
{ "xor", 3, 3, 0, 1 },
#define F_ATO_MINU
{ "minu", 4, 3, 0, 1 },
#define F_ATO_MAXU
{ "maxu", 5, 3, 0, 1 },
#define F_ATO_MIN
{ "min", 6, 3, 0, 1 },
#define F_ATO_MAX
{ "max", 7, 3, 0, 1 },
#define F_ND
{ "nd", 0, 1, 5, 0 },
#define F_D
{ "d", 1, 1, 5, 1 },
#define F_DFAKE
{ "d", 0, 0, 0, 1 },
#define F_DNZ_ND
{ "nd", 0, 1, 16, 0 },
#define F_DNZ_D
{ "d", 1, 1, 16, 1 },
#define F_SIZEB1
{ "b", 1, 2, 1, 1 },
#define F_SIZEB7
{ "b", 1, 2, 7, 1 },
#define F_SIZEB17
{ "b", 1, 2, 17, 1 },
#define F_SIZEW1
{ "w", 2, 2, 1, 0 },
#define F_SIZEW7
{ "w", 2, 2, 7, 0 },
#define F_SIZEW17
{ "w", 2, 2, 17, 0 },
#define F_SIGN6
{ "x", 1, 1, 6, 1 },
#define F_SIGN16
{ "x", 1, 1, 16, 1 },
#define F_SIGNX
{ "x", 0, 0, 0, 1 },
#define F_A3
{ "a", 1, 2, 3, 0 },
#define F_A9
{ "a", 1, 2, 9, 0 },
#define F_A22
{ "a", 1, 2, 22, 0 },
#define F_AW3
{ "aw", 1, 2, 3, 1 },
#define F_AW9
{ "aw", 1, 2, 9, 1 },
#define F_AW22
{ "aw", 1, 2, 22, 1 },
#define F_AB3
{ "ab", 2, 2, 3, 1 },
#define F_AB9
{ "ab", 2, 2, 9, 1 },
#define F_AB22
{ "ab", 2, 2, 22, 1 },
#define F_AS3
{ "as", 3, 2, 3, 1 },
#define F_AS9
{ "as", 3, 2, 9, 1 },
#define F_AS22
{ "as", 3, 2, 22, 1 },
#define F_ASFAKE
{ "as", 0, 0, 0, 1 },
#define F_AA128
{ "a", 2, 2, 15, 0 },
#define F_AA128W
{ "aw", 2, 2, 15, 1 },
#define F_AA128B
{ "ab", 3, 2, 15, 1 },
#define F_AA128S
{ "as", 1, 2, 15, 1 },
#define F_DI5
{ "di", 1, 1, 5, 1 },
#define F_DI11
{ "di", 1, 1, 11, 1 },
#define F_DI14
{ "di", 1, 1, 14, 1 },
#define F_DI15
{ "di", 1, 1, 15, 1 },
#define F_NT
{ "nt", 0, 1, 3, 1 },
#define F_T
{ "t", 1, 1, 3, 1 },
#define F_H1
{ "h", 2, 2, 1, 1 },
#define F_H7
{ "h", 2, 2, 7, 1 },
#define F_H17
{ "h", 2, 2, 17, 1 },
#define F_SIZED
{ "dd", 8, 0, 0, 0 },
#define F_SIZEL
{ "dl", 8, 0, 0, 0 },
#define F_SIZEW
{ "xx", 4, 0, 0, 0 },
#define F_NE
{ "ne", 0, 0, 0, 1 },
#define F_NPS_CL
{ "cl", 0, 0, 0, 1 },
#define F_NPS_NA
{ "na", 1, 1, 9, 1 },
#define F_NPS_SR
{ "s", 1, 1, 13, 1 },
#define F_NPS_M
{ "m", 1, 1, 7, 1 },
#define F_NPS_FLAG
{ "f", 1, 1, 20, 1 },
#define F_NPS_R
{ "r", 1, 1, 15, 1 },
#define F_NPS_RW
{ "rw", 0, 1, 7, 1 },
#define F_NPS_RD
{ "rd", 1, 1, 7, 1 },
#define F_NPS_WFT
{ "wft", 0, 0, 0, 1 },
#define F_NPS_IE1
{ "ie1", 1, 2, 8, 1 },
#define F_NPS_IE2
{ "ie2", 2, 2, 8, 1 },
#define F_NPS_IE12
{ "ie12", 3, 2, 8, 1 },
#define F_NPS_SYNC_RD
{ "rd", 0, 1, 6, 1 },
#define F_NPS_SYNC_WR
{ "wr", 1, 1, 6, 1 },
#define F_NPS_HWS_OFF
{ "off", 0, 0, 0, 1 },
#define F_NPS_HWS_RESTORE
{ "restore", 0, 0, 0, 1 },
#define F_NPS_SX
{ "sx", 1, 1, 14, 1 },
#define F_NPS_AR
{ "ar", 0, 1, 0, 1 },
#define F_NPS_AL
{ "al", 1, 1, 0, 1 },
#define F_NPS_S
{ "s", 0, 0, 0, 1 },
#define F_NPS_ZNCV_RD
{ "rd", 0, 1, 15, 1 },
#define F_NPS_ZNCV_WR
{ "wr", 1, 1, 15, 1 },
#define F_NPS_P0
{ "p0", 0, 0, 0, 1 },
#define F_NPS_P1
{ "p1", 0, 0, 0, 1 },
#define F_NPS_P2
{ "p2", 0, 0, 0, 1 },
#define F_NPS_P3
{ "p3", 0, 0, 0, 1 },
#define F_NPS_LDBIT_DI
{ "di", 0, 0, 0, 1 },
#define F_NPS_LDBIT_CL1
{ "cl", 1, 1, 6, 1 },
#define F_NPS_LDBIT_CL2
{ "cl", 1, 1, 16, 1 },
#define F_NPS_LDBIT_X2_1
{ "x2", 1, 2, 9, 1 },
#define F_NPS_LDBIT_X2_2
{ "x2", 1, 2, 22, 1 },
#define F_NPS_LDBIT_X4_1
{ "x4", 2, 2, 9, 1 },
#define F_NPS_LDBIT_X4_2
{ "x4", 2, 2, 22, 1 },
#define F_NPS_CORE
{ "core", 1, 3, 6, 1 },
#define F_NPS_CLSR
{ "clsr", 2, 3, 6, 1 },
#define F_NPS_ALL
{ "all", 3, 3, 6, 1 },
#define F_NPS_GIC
{ "gic", 4, 3, 6, 1 },
#define F_NPS_RSPI_GIC
{ "gic", 5, 3, 6, 1 },
};
const struct arc_flag_class arc_flag_classes[] = {
#define C_EMPTY
{ F_CLASS_NONE, 0, 0, { F_NULL } },
#define C_CC_EQ
{ F_CLASS_IMPLICIT | F_CLASS_COND, 0, 0, { F_EQUAL } },
#define C_CC_GE
{ F_CLASS_IMPLICIT | F_CLASS_COND, 0, 0, { F_GE } },
#define C_CC_GT
{ F_CLASS_IMPLICIT | F_CLASS_COND, 0, 0, { F_GT } },
#define C_CC_HI
{ F_CLASS_IMPLICIT | F_CLASS_COND, 0, 0, { F_HI } },
#define C_CC_HS
{ F_CLASS_IMPLICIT | F_CLASS_COND, 0, 0, { F_NOTCARRY } },
#define C_CC_LE
{ F_CLASS_IMPLICIT | F_CLASS_COND, 0, 0, { F_LE } },
#define C_CC_LO
{ F_CLASS_IMPLICIT | F_CLASS_COND, 0, 0, { F_CARRY } },
#define C_CC_LS
{ F_CLASS_IMPLICIT | F_CLASS_COND, 0, 0, { F_LS } },
#define C_CC_LT
{ F_CLASS_IMPLICIT | F_CLASS_COND, 0, 0, { F_LT } },
#define C_CC_NE
{ F_CLASS_IMPLICIT | F_CLASS_COND, 0, 0, { F_NOTEQUAL } },
#define C_AA_AB
{ F_CLASS_IMPLICIT | F_CLASS_WB, 0, 0, { F_AB3 } },
#define C_AA_AW
{ F_CLASS_IMPLICIT | F_CLASS_WB, 0, 0, { F_AW3 } },
#define C_ZZ_D
{ F_CLASS_IMPLICIT | F_CLASS_ZZ, 0, 0, { F_SIZED } },
#define C_ZZ_L
{ F_CLASS_IMPLICIT | F_CLASS_ZZ, 0, 0, { F_SIZEL } },
#define C_ZZ_W
{ F_CLASS_IMPLICIT | F_CLASS_ZZ, 0, 0, { F_SIZEW } },
#define C_ZZ_H
{ F_CLASS_IMPLICIT | F_CLASS_ZZ, 0, 0, { F_H1 } },
#define C_ZZ_B
{ F_CLASS_IMPLICIT | F_CLASS_ZZ, 0, 0, { F_SIZEB1 } },
#define C_CC
{ F_CLASS_OPTIONAL | F_CLASS_EXTEND | F_CLASS_COND, 0, 0, { F_ALWAYS, F_RA, F_EQUAL, F_ZERO, F_NOTEQUAL, F_NOTZERO, F_POZITIVE, F_PL, F_NEGATIVE, F_MINUS, F_CARRY, F_CARRYSET, F_LOWER, F_CARRYCLR, F_NOTCARRY, F_HIGHER, F_OVERFLOWSET, F_OVERFLOW, F_NOTOVERFLOW, F_OVERFLOWCLR, F_GT, F_GE, F_LT, F_LE, F_HI, F_LS, F_PNZ, F_NJ, F_NM, F_NO_T } },
#define C_AA_ADDR3
{ F_CLASS_OPTIONAL | F_CLASS_WB, 0, 0, { F_A3, F_AW3, F_AB3, F_AS3 } },
#define C_AA27
{ F_CLASS_OPTIONAL | F_CLASS_WB, 0, 0, { F_A3, F_AW3, F_AB3, F_AS3 } },
#define C_AS27
{ F_CLASS_OPTIONAL, 0, 0, { F_AS3 } },
#define C_AA_ADDR9
{ F_CLASS_OPTIONAL | F_CLASS_WB, 0, 0, { F_A9, F_AW9, F_AB9, F_AS9 } },
#define C_AA21
{ F_CLASS_OPTIONAL | F_CLASS_WB, 0, 0, { F_A9, F_AW9, F_AB9, F_AS9 } },
#define C_AAB21
{ F_CLASS_OPTIONAL | F_CLASS_WB, 0, 0, { F_A9, F_AW9, F_AB9 } },
#define C_AA_ADDR22
{ F_CLASS_OPTIONAL | F_CLASS_WB, 0, 0, { F_A22, F_AW22, F_AB22, F_AS22 } },
#define C_AA8
{ F_CLASS_OPTIONAL | F_CLASS_WB, 0, 0, { F_A22, F_AW22, F_AB22, F_AS22 } },
#define C_AAB8
{ F_CLASS_OPTIONAL | F_CLASS_WB, 0, 0, { F_A22, F_AW22, F_AB22 } },
#define C_F
{ F_CLASS_OPTIONAL, 0, 0, { F_FLAG } },
#define C_FHARD
{ F_CLASS_OPTIONAL, 0, 0, { F_FFAKE } },
#define C_RL
{ F_CLASS_OPTIONAL, 0, 0, { F_RL } },
#define C_AQ
{ F_CLASS_OPTIONAL, 0, 0, { F_AQ } },
#define C_ATOP
{ F_CLASS_REQUIRED, 0, 0, { F_ATO_ADD, F_ATO_OR, F_ATO_AND, F_ATO_XOR, F_ATO_MINU, F_ATO_MAXU, F_ATO_MIN, F_ATO_MAX } },
#define C_T
{ F_CLASS_OPTIONAL, 0, 0, { F_NT, F_T } },
#define C_D
{ F_CLASS_OPTIONAL, 0, 0, { F_ND, F_D } },
#define C_DNZ_D
{ F_CLASS_OPTIONAL, 0, 0, { F_DNZ_ND, F_DNZ_D } },
#define C_DHARD
{ F_CLASS_OPTIONAL, 0, 0, { F_DFAKE } },
#define C_DI20
{ F_CLASS_OPTIONAL, 0, 0, { F_DI11 } },
#define C_DI14
{ F_CLASS_OPTIONAL, 0, 0, { F_DI14 } },
#define C_DI16
{ F_CLASS_OPTIONAL, 0, 0, { F_DI15 } },
#define C_DI26
{ F_CLASS_OPTIONAL, 0, 0, { F_DI5 } },
#define C_X25
{ F_CLASS_OPTIONAL, 0, 0, { F_SIGN6 } },
#define C_X15
{ F_CLASS_OPTIONAL, 0, 0, { F_SIGN16 } },
#define C_XHARD
{ F_CLASS_OPTIONAL, 0, 0, { F_SIGNX } },
#define C_X
{ F_CLASS_OPTIONAL, 0, 0, { F_SIGNX } },
#define C_ZZ13
{ F_CLASS_OPTIONAL, 0, 0, { F_SIZEB17, F_SIZEW17, F_H17 } },
#define C_ZZ23
{ F_CLASS_OPTIONAL, 0, 0, { F_SIZEB7, F_SIZEW7, F_H7 } },
#define C_ZZ29
{ F_CLASS_OPTIONAL, 0, 0, { F_SIZEB1, F_SIZEW1, F_H1 } },
#define C_ZZW6
{ F_CLASS_OPTIONAL, 0, 0, { F_SIZEB1 } },
#define C_ZZH1
{ F_CLASS_OPTIONAL, 0, 0, { F_SIZEW1, F_H1 } },
#define C_AS
{ F_CLASS_OPTIONAL, 0, 0, { F_ASFAKE } },
#define C_AAHARD13
{ F_CLASS_OPTIONAL, 0, 0, { F_ASFAKE } },
#define C_NE
{ F_CLASS_REQUIRED, 0, 0, { F_NE } },
#define C_NPS_CL
{ F_CLASS_REQUIRED, 0, 0, { F_NPS_CL } },
#define C_NPS_NA
{ F_CLASS_OPTIONAL, 0, 0, { F_NPS_NA } },
#define C_NPS_SR
{ F_CLASS_OPTIONAL, 0, 0, { F_NPS_SR } },
#define C_NPS_M
{ F_CLASS_OPTIONAL, 0, 0, { F_NPS_M } },
#define C_NPS_F
{ F_CLASS_OPTIONAL, 0, 0, { F_NPS_FLAG } },
#define C_NPS_R
{ F_CLASS_OPTIONAL, 0, 0, { F_NPS_R } },
#define C_NPS_SCHD_RW
{ F_CLASS_REQUIRED, 0, 0, { F_NPS_RW, F_NPS_RD } },
#define C_NPS_SCHD_TRIG
{ F_CLASS_REQUIRED, 0, 0, { F_NPS_WFT } },
#define C_NPS_SCHD_IE
{ F_CLASS_OPTIONAL, 0, 0, { F_NPS_IE1, F_NPS_IE2, F_NPS_IE12 } },
#define C_NPS_SYNC
{ F_CLASS_REQUIRED, 0, 0, { F_NPS_SYNC_RD, F_NPS_SYNC_WR } },
#define C_NPS_HWS_OFF
{ F_CLASS_REQUIRED, 0, 0, { F_NPS_HWS_OFF } },
#define C_NPS_HWS_RESTORE
{ F_CLASS_REQUIRED, 0, 0, { F_NPS_HWS_RESTORE } },
#define C_NPS_SX
{ F_CLASS_OPTIONAL, 0, 0, { F_NPS_SX } },
#define C_NPS_AR_AL
{ F_CLASS_REQUIRED, 0, 0, { F_NPS_AR, F_NPS_AL } },
#define C_NPS_S
{ F_CLASS_REQUIRED, 0, 0, { F_NPS_S } },
#define C_NPS_ZNCV
{ F_CLASS_REQUIRED, 0, 0, { F_NPS_ZNCV_RD, F_NPS_ZNCV_WR } },
#define C_NPS_P0
{ F_CLASS_REQUIRED, 0, 0, { F_NPS_P0 } },
#define C_NPS_P1
{ F_CLASS_REQUIRED, 0, 0, { F_NPS_P1 } },
#define C_NPS_P2
{ F_CLASS_REQUIRED, 0, 0, { F_NPS_P2 } },
#define C_NPS_P3
{ F_CLASS_REQUIRED, 0, 0, { F_NPS_P3 } },
#define C_NPS_LDBIT_DI
{ F_CLASS_REQUIRED, 0, 0, { F_NPS_LDBIT_DI } },
#define C_NPS_LDBIT_CL1
{ F_CLASS_OPTIONAL, 0, 0, { F_NPS_LDBIT_CL1 } },
#define C_NPS_LDBIT_CL2
{ F_CLASS_OPTIONAL, 0, 0, { F_NPS_LDBIT_CL2 } },
#define C_NPS_LDBIT_X_1
{ F_CLASS_OPTIONAL, 0, 0, { F_NPS_LDBIT_X2_1, F_NPS_LDBIT_X4_1 } },
#define C_NPS_LDBIT_X_2
{ F_CLASS_OPTIONAL, 0, 0, { F_NPS_LDBIT_X2_2, F_NPS_LDBIT_X4_2 } },
#define C_NPS_CORE
{ F_CLASS_REQUIRED, 0, 0, { F_NPS_CORE } },
#define C_NPS_CLSR
{ F_CLASS_REQUIRED, 0, 0, { F_NPS_CLSR } },
#define C_NPS_ALL
{ F_CLASS_REQUIRED, 0, 0, { F_NPS_ALL } },
#define C_NPS_GIC
{ F_CLASS_REQUIRED, 0, 0, { F_NPS_GIC } },
#define C_NPS_RSPI_GIC
{ F_CLASS_REQUIRED, 0, 0, { F_NPS_RSPI_GIC } },
#define C_FPCC
{ F_CLASS_OPTIONAL | F_CLASS_EXTEND | F_CLASS_COND, insert_fs2, extract_fs2, { F_ALWAYS, F_RA, F_EQUAL, F_ZERO, F_NOTEQUAL, F_NOTZERO, F_POZITIVE, F_PL, F_NEGATIVE, F_MINUS, F_CARRY, F_CARRYSET, F_LOWER, F_CARRYCLR, F_NOTCARRY, F_HIGHER, F_OVERFLOWSET, F_OVERFLOW, F_NOTOVERFLOW, F_OVERFLOWCLR, F_GT, F_GE, F_LT, F_LE, F_HI, F_LS, F_PNZ, F_NJ, F_NM, F_NO_T } },
#define C_AA_128
{ F_CLASS_OPTIONAL | F_CLASS_WB, 0, 0, { F_AA128, F_AA128W, F_AA128B, F_AA128S } },
#define C_AS_128
{ F_CLASS_OPTIONAL, 0, 0, { F_AA128S } },
#define C_AA_128S
{ F_CLASS_OPTIONAL | F_CLASS_WB, insert_qq, extract_qq, { F_AA128, F_AA128W, F_AA128B, F_AA128S } },
#define C_AS_128S
{ F_CLASS_OPTIONAL, insert_qq, extract_qq, { F_AA128S } },
};
